Group member:
+Name: Tran Quang Huy, Student ID: s3680599
+Name: Tang Nhat Minh, Student ID: s3754704
+Name: Dong Vu Minh Phuc, Student ID: s3700622

Work distribution:

+Tran Quang Huy:
_Build the backend and database.
_Build CRUD for Semester and Course and their filter, search functions.
_Build Admin CRUD and Admin login function.
_Build the detail page for student projects.

+Tang Nhat Minh:
_ Build CRUD for student projects.

+Dong Vu Minh Phuc:
_ Design UI for the page.

Link to the demo video: https://youtu.be/olJ9IdkfBZw

Admin sample to login:
name: Admin
password: Abc1234