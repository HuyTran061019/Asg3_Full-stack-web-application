import React from 'react'
import { BrowserRouter, Link, Route } from 'react-router-dom'


const url = 'http://localhost:9000/students'
const url2 = 'http://localhost:9000/categories'
const url3 = 'http://localhost:9000/semesters'

export default class DifferentView extends React.Component {

    constructor(props) {
        super(props)
        this.state = {

            // students project 
            students: [],
            id: '',

            s1Id: '',
            s1Name: '',
            s1Year: '',

            s2Id: '',
            s2Name: '',
            s2Year: '',

            s3Id: '',
            s3Name: '',
            s3Year: '',

            courseId: '',
            courseName: '',
            semester: '',
            asgName: '',
            asgDescription: '',
            asgPercentage: '',
            techUsed: '',
            scope: '',
            description: '',
            industryLink: '',
            application: '',
            photo: '',
            photo2: '',
            photo3: '',


            addNew: true,
            filtered: [],
            keywordSearch: '',

            // courses
            categories: [],
            categoriesId: '',
            categoriesName: '',
            categoriesAddNew: true,

            // semesters
            sems: [],
            semsId: '',
            semsName: '',
            semsAddNew: true


        }

    }
    //No filter function
    fetchProduct() {
        fetch(url).then(res => res.json())
            .then(json => {

                var list = json.filter(s => typeof s.id !== 'undefined' && s.id !== "")
                this.setState({ students: list })
            })
    }
    //FIlter with courses function
    fetchCourse(name) {
        fetch(url).then(res => res.json())
            .then(json => {

                var list = json.filter(s => typeof s.id !== 'undefined' && s.id !== "" && s.courseName == name)
                this.setState({ students: list })
            })
    }
    //Filter with semester function
    fetchSemester(name) {
        fetch(url).then(res => res.json())
            .then(json => {

                var list = json.filter(s => typeof s.id !== 'undefined' && s.id !== "" && s.semester == name)
                this.setState({ students: list })
            })
    }
    //search course
    fetchSearch(wordSearch) {
        fetch(url).then(res => res.json())
            .then(json => {

                var list = json.filter(s => typeof s.id !== 'undefined' && s.id !== "" && (s.courseName.toLowerCase()).includes(wordSearch.toLowerCase()))


                this.setState({ students: list })
            })


    }


    fetchData() {
        fetch(url).then(res => res.json())
            .then(json => {

                var list = json.filter(s => typeof s.id !== 'undefined' && s.id !== "")
                this.setState({ students: list })
            })
    }

    fetchData2() {
        fetch(url2).then(res => res.json())
            .then(json => {

                var list = json.filter(s => typeof s.id !== 'undefined' && s.id !== "" && s.name !== 'undefined' && s.name !== "")
                this.setState({ categories: list })
            })
    }
    fetchData3() {
        fetch(url3).then(res => res.json())
            .then(json => {

                var list = json.filter(s => typeof s.id !== 'undefined' && s.id !== "" && s.name !== 'undefined' && s.name !== "")
                this.setState({ sems: list })
            })
    }





    componentDidMount() {
        this.fetchData()
        this.fetchData2()
        this.fetchData3()
    }






    handleChange(e) {
        var obj = {}
        obj[e.target.name] = e.target.value
        this.setState(obj)
    }

    save() {
        if (this.state.addNew === true) {
            fetch(url, {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    id: this.state.id, s1Id: this.state.s1Id, s1Name: this.state.s1Name, s1Year: this.state.s1Year, s2Id: this.state.s2Id, s2Name: this.state.s2Name, s2Year: this.state.s2Year,
                    s3Id: this.state.s3Id, s3Name: this.state.s3Name, s3Year: this.state.s3Year, courseId: this.state.courseId, courseName: this.state.courseName, semester: this.state.semester, asgName: this.state.asgName, asgDescription: this.state.asgDescription, asgPercentage: this.state.asgPercentage, techUsed: this.state.techUsed, scope: this.state.scope, description: this.state.description, industryLink: this.state.industryLink, application: this.state.application, photo: this.state.photo, photo2: this.state.photo2, photo3: this.state.photo3
                })
            }).then(res => res.json())
                .then(json => this.fetchData())
        }
        else {
            fetch(url, {
                method: 'put',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    id: this.state.id, s1Id: this.state.s1Id, s1Name: this.state.s1Name, s1Year: this.state.s1Year, s2Id: this.state.s2Id, s2Name: this.state.s2Name, s2Year: this.state.s2Year,
                    s3Id: this.state.s3Id, s3Name: this.state.s3Name, s3Year: this.state.s3Year, courseId: this.state.courseId, courseName: this.state.courseName, semester: this.state.semester, asgName: this.state.asgName, asgDescription: this.state.asgDescription, asgPercentage: this.state.asgPercentage, techUsed: this.state.techUsed, scope: this.state.scope, description: this.state.description, industryLink: this.state.industryLink, application: this.state.application, photo: this.state.photo, photo2: this.state.photo2, photo3: this.state.photo3
                })
            }).then(res => res.json())
                .then(json => this.fetchData())
        }

    }

    save2() {
        if (this.state.categoriesAddNew === true) {
            fetch(url2, {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ id: this.state.categoriesId, name: this.state.categoriesName })
            }).then(res => res.json())
                .then(json => this.fetchData2())
        }
        else {
            fetch(url2, {
                method: 'put',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ id: this.state.categoriesId, name: this.state.categoriesName })
            }).then(res => res.json())
                .then(json => this.fetchData2())
        }

    }


    save3() {
        if (this.state.semsAddNew === true) {
            fetch(url3, {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ id: this.state.semsId, name: this.state.semsName })
            }).then(res => res.json())
                .then(json => this.fetchData3())
        }
        else {
            fetch(url3, {
                method: 'put',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ id: this.state.semsId, name: this.state.semsName })
            }).then(res => res.json())
                .then(json => this.fetchData3())
        }

    }




    delete(id) {
        if (confirm('Do you want to delete?')) {
            fetch(url + "/" + id, {
                method: 'delete',
            }).then(res => res.json())
                .then(json => this.fetchData())
        }

    }

    delete2(id) {
        if (confirm('Do you want to delete?')) {
            fetch(url2 + "/" + id, {
                method: 'delete',
            }).then(res => res.json())
                .then(json => this.fetchData2())
        }

    }


    delete3(id) {
        if (confirm('Do you want to delete?')) {
            fetch(url3 + "/" + id, {
                method: 'delete',
            }).then(res => res.json())
                .then(json => this.fetchData3())
        }

    }
    upload() {

        const myFileInputs = document.querySelector("input[name='file']")

        const formData = new FormData()
        formData.append('myFile', myFileInputs.files[0])

        fetch('http://localhost:9000/uploadfile', {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                console.log(data)
                this.setState({ photo: data.originalname })
            })
    }
    upload2() {

        const myFileInputs = document.querySelector("input[name='file2']")

        const formData = new FormData()
        formData.append('myFile', myFileInputs.files[0])

        fetch('http://localhost:9000/uploadfile', {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                console.log(data)
                this.setState({ photo2: data.originalname })
            })
    }
    upload3() {

        const myFileInputs = document.querySelector("input[name='file3']")

        const formData = new FormData()
        formData.append('myFile', myFileInputs.files[0])

        fetch('http://localhost:9000/uploadfile', {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                console.log(data)
                this.setState({ photo3: data.originalname })
            })
    }

    add3(semsId, semsName) {
        this.setState({ semsId: '', semsName: '', semsAddNew: true })
    }

    edit3(semsId, semsName, ) {
        this.setState({ semsId: semsId, semsName: semsName, semsAddNew: false })
    }


    add2(categoriesId, categoriesName) {
        this.setState({ categoriesId: '', categoriesName: '', categoriesAddNew: true })
    }

    edit2(categoriesId, categoriesName, ) {
        this.setState({ categoriesId: categoriesId, categoriesName: categoriesName, categoriesAddNew: false })
    }





    add(id, name, year, courseId, courseName, semester, asgName, asgDescription, asgPercentage, techUsed, scope, description, industryLink, application, photo, photo2, photo3) {
        this.setState({ id: '', s1Id: '', s1Name: '', s1Year: '', s2Id: '', s2Name: '', s2Year: '', s3Id: '', s3Name: '', s3Year: '', courseId: '', courseName: '', semester: '', asgName: '', asgDescription: '', asgPercentage: '', techUsed: '', scope: '', description: '', industryLink: '', application: '', photo: '', photo2: '', photo3: '', addNew: true })
    }

    edit(id, s1Id, s1Name, s1Year, s2Id, s2Name, s2Year, s3Id, s3Name, s3Year, courseId, courseName, semester, asgName, asgDescription, asgPercentage, techUsed, scope, description, industryLink, application, photo, photo2, photo3) {
        this.setState({ id: id, s1Id: s1Id, s1Name: s1Name, s1Year: s1Year, s2Id: s2Id, s2Name: s2Name, s2Year: s2Year, s3Id: s3Id, s3Name: s3Name, s3Year: s3Year, courseId: courseId, courseName: courseName, semester: semester, asgName: asgName, asgDescription: asgDescription, asgPercentage: asgPercentage, techUsed: techUsed, scope: scope, description: description, industryLink: industryLink, application: application, photo: photo, photo2: photo2, photo3: photo3, addNew: false })
    }

    render() {
        return (
            <div class="container mt-n3">
                <div class="row">
                    <div class="col-md-4" style={{ backgroundColor: 'lightgrey' }} >
                        <Link to="/" className="nav-link">
                            <button class="btn btn-dark ml-n3" type="button" >
                                <div class="font-weight-bold" style={{ color: "white" }}> Log out </div>
                            </button>
                        </Link>
                        <h3 class="pt-2">Semester Management</h3>
                        <div>
                            {/* show list of Categories +CRUD */}
                            {this.state.sems.map(i =>
                                <div>
                                    <div>{i.id} | {i.name}
                                        <button onClick={this.delete3.bind(this, i.id)}>Delete</button>

                                        <button onClick={this.edit3.bind(this, i.id, i.name)}>Edit</button>
                                    </div>
                                </div>
                            )}
                        </div>
                        <h5>Add Semester</h5>
                        Semester id: <input type="text" id="semsId" name="semsId" className="form-control" value={this.state.semsId} onChange={this.handleChange.bind(this)} />


                        Semester name: <input class="mt-1" type="text" id="semsName" name="semsName" className="form-control" value={this.state.semsName}
                            onChange={this.handleChange.bind(this)} />
                        <br />
                        <button class="btn btn-success  mr-1 mt-1" onClick={this.save3.bind(this)}>Save</button>
                        <button class="btn btn-success  mr-2 mt-1" onClick={this.add3.bind(this)}>Add new</button>
                        <br />
                        <h3 class="pt-2">Course Management</h3>
                        <div>
                            {/* show list of Categories +CRUD */}
                            {this.state.categories.map(i =>
                                <div>
                                    <div>{i.id} | {i.name}
                                        <button onClick={this.delete2.bind(this, i.id)}>Delete</button>

                                        <button onClick={this.edit2.bind(this, i.id, i.name)}>Edit</button>
                                    </div>
                                </div>
                            )}
                        </div>

                        <h5>Add Course</h5>
                        Course id: <input type="text" id="categoriesId" name="categoriesId" className="form-control" value={this.state.categoriesId} onChange={this.handleChange.bind(this)} />


                        Course name: <input class="mt-1" type="text" id="categoriesName" name="categoriesName" className="form-control" value={this.state.categoriesName}
                            onChange={this.handleChange.bind(this)} />
                        <br />
                        <button class="btn btn-success  mr-1 mt-1" onClick={this.save2.bind(this)}>Save</button>
                        <button class="btn btn-success  mr-2 mt-1" onClick={this.add2.bind(this)}>Add new</button>
                        <br />


                        <div>
                            {/* Search Bar */}
                            <h3>  Search for Project's course:</h3>

                            <input type="text" placeholder="Course" id="keywordSearch" name="keywordSearch"
                                onChange={this.handleChange.bind(this)} value={this.state.keywordSearch} />
                            <button class="btn btn-success " onClick={this.fetchSearch.bind(this, this.state.keywordSearch)}>Search</button>

                            {/* Filter  */}
                            <h3> Filter option: </h3>
                            {/* Semester Filter  */}
                            <div class="dropdown mt-3 mb-2">
                                <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" style={{ width: "100%" }}>Semesters
    <span class="caret"></span></button>
                                <ul class='dropdown-menu' style={{ width: "100%" }}>

                                    {/* show list of Semesters*/}

                                    {this.state.sems.map(i =>
                                        <div>
                                            <li  ><a href="#" onClick={this.fetchSemester.bind(this, i.name)}>{i.name}</a></li>
                                        </div>
                                    )}
                                    <li  ><a href="#" onClick={this.fetchProduct.bind(this)}>No Filter</a></li>
                                </ul>
                            </div>

                            {/* Coures Filter */}
                            <div class="dropdown mb-10">
                                <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" style={{ width: "100%" }}>Courses
    <span class="caret"></span></button>
                                <ul class='dropdown-menu' style={{ width: "100%" }}>

                                    {/* show list of Categories*/}

                                    {this.state.categories.map(i =>
                                        <div>
                                            <li  ><a href="#" onClick={this.fetchCourse.bind(this, i.name)}>{i.name}</a></li>
                                        </div>
                                    )}
                                    <li  ><a href="#" onClick={this.fetchProduct.bind(this)}>No Filter</a></li>
                                </ul>
                            </div>



                            <h3>Admin Management:</h3>
                            <Link to="/AdminManagement" className="nav-link">
                                <button class="btn btn-info ml-n3 " type="button" style={{ width: "50%", height: "50px" }} > Edit Admin </button>
                            </Link>
                        </div>
                    </div>
                    <div class="col-md-8">
                        {/* show list of students +CRUD */}
                        <h1 class="pt-2">Student project Management</h1>
                        <h2>Student project list:</h2>
                        <div>
                            {this.state.students.map(s =>
                                <div>
                                    <div>{s.id} | {s.s1Id} | {s.s1Name} |{s.s1Year} |{s.s2Id} | {s.s2Name} |{s.s2Year} |{s.s3Id} | {s.s3Name} |{s.s3Year} | {s.courseId} | {s.courseName} | {s.semester}| {s.asgName} |{s.asgDescription} |{s.asgPercentage} |{s.techUsed} | {s.scope} | {s.description} | {s.industryLink} | {s.application} | {s.photo} | {s.photo2} | {s.photo3} |
                                        <button onClick={this.delete.bind(this, s.id)}>Delete</button>

                                        <button onClick={this.edit.bind(this, s.id, s.s1Id, s.s1Name, s.s1Year, s.s2Id, s.s2Name, s.s2Year, s.s3Id, s.s3Name, s.s3Year, s.courseId, s.courseName, s.semester, s.asgName, s.asgDescription, s.asgPercentage, s.techUsed, s.scope, s.description, s.industryLink, s.application, s.photo, s.photo2, s.photo3)}>Edit</button>
                                    </div>
                                </div>
                            )}
                        </div>

                        {/*CRUD student project input */}
                        <h2>Add Student project</h2>

                        Project id: <input class="mt-1" type="text" id="id" name="id" className="form-control" value={this.state.id} onChange={this.handleChange.bind(this)} />
                        <br />

                        Student 1 id: <input class="mt-1" type="text" id="s1Id" name="s1Id" className="form-control" value={this.state.s1Id}
                            onChange={this.handleChange.bind(this)} />
                        <br />
                        Student 1 name: <input class="mt-1" type="text" id="s1Name" name="s1Name" className="form-control" value={this.state.s1Name}
                            onChange={this.handleChange.bind(this)} />
                        <br />
                        Student 1 year: <input class="mt-1" type="text" id="s1year" name="s1Year" className="form-control" value={this.state.s1Year}
                            onChange={this.handleChange.bind(this)} />
                        <br />

                        Student 2 id: <input class="mt-1" type="text" id="s2Id" name="s2Id" className="form-control" value={this.state.s2Id}
                            onChange={this.handleChange.bind(this)} />
                        <br />
                        Student 2 name: <input class="mt-1" type="text" id="s2Name" name="s2Name" className="form-control" value={this.state.s2Name}
                            onChange={this.handleChange.bind(this)} />
                        <br />
                        Student 2 year: <input class="mt-1" type="text" id="s2Year" name="s2Year" className="form-control" value={this.state.s2Year}
                            onChange={this.handleChange.bind(this)} />
                        <br />

                        Student 3 id: <input class="mt-1" type="text" id="s3Id" name="s3Id" className="form-control" value={this.state.s3Id}
                            onChange={this.handleChange.bind(this)} />
                        <br />
                        Student 3 name: <input class="mt-1" type="text" id="s3Name" name="s3Name" className="form-control" value={this.state.s3Name}
                            onChange={this.handleChange.bind(this)} />
                        <br />
                        Student 3 year: <input class="mt-1" type="text" id="s3Year" name="s3Year" className="form-control" value={this.state.s3Year}
                            onChange={this.handleChange.bind(this)} />
                        <br />


                        Course Id: <input class="mt-1" type="text" id="courseId" name="courseId" className="form-control" value={this.state.courseId}
                            onChange={this.handleChange.bind(this)} />
                        <br />
                        Course name: <input class="mt-1" type="text" id="courseName" name="courseName" className="form-control" value={this.state.courseName}
                            onChange={this.handleChange.bind(this)} />
                        <br />
                        Semester: <input class="mt-1" type="text" id="semester" name="semester" className="form-control" value={this.state.semester}
                            onChange={this.handleChange.bind(this)} />
                        <br />
                        Assignment Name: <input class="mt-1" type="text" id="asgName" name="asgName" className="form-control" value={this.state.asgName}
                            onChange={this.handleChange.bind(this)} />
                        <br />
                        Assignment description: <input class="mt-1" type="text" id="asgDescription" name="asgDescription" className="form-control" value={this.state.asgDescription}
                            onChange={this.handleChange.bind(this)} />
                        <br />
                        Assignment Percentage: <input class="mt-1" type="text" id="asgPercentage" name="asgPercentage" className="form-control" value={this.state.asgPercentage}
                            onChange={this.handleChange.bind(this)} />
                        <br />
                        Tech used: <input class="mt-1" type="text" id="techUsed" name="techUsed" className="form-control" value={this.state.techUsed}
                            onChange={this.handleChange.bind(this)} />
                        <br />
                        Scope: <input class="mt-1" type="text" id="scope" name="scope" className="form-control" value={this.state.scope}
                            onChange={this.handleChange.bind(this)} />
                        <br />
                        Descriptions: <input class="mt-1" type="text" id="description" name="description" className="form-control" value={this.state.description}
                            onChange={this.handleChange.bind(this)} />
                        <br />
                        Industry Link: <input class="mt-1" type="text" id="industryLink" name="industryLink" className="form-control" value={this.state.industryLink}
                            onChange={this.handleChange.bind(this)} />
                        <br />
                        Application: <input class="mt-1" type="text" id="application" name="application" className="form-control" value={this.state.application}
                            onChange={this.handleChange.bind(this)} />
                        <br />

                        Photo:

                        <div class="mb-2">Photo 1:
                            <input type='text' id='photo' name='photo' value={this.state.photo} />
                            <input type="file" name="file" />
                            <button class="btn btn-primary " onClick={this.upload.bind(this)}>Upload</button>
                        </div>

                        <div class="mb-2"> Photo 2:
                            <input type='text' id='photo2' name='photo2' value={this.state.photo2} />
                            <input type="file" name="file2" />
                            <button class="btn btn-primary" onClick={this.upload2.bind(this)}>Upload</button>
                        </div>

                        <div class="mb-2">Photo 3:
                            <input type='text' id='photo3' name='photo3' value={this.state.photo3} />
                            <input type="file" name="file3" />
                            <button class="btn btn-primary" onClick={this.upload3.bind(this)}>Upload</button>
                        </div>


                        <button class="btn btn-success  mr-1 mt-1" onClick={this.save.bind(this)}>Save</button>
                        <button class="btn btn-success  mr-2 mt-1" onClick={this.add.bind(this)}>Add new</button>

                        {/* show list of students +CRUD */}
                        <h2>Student project list: </h2>
                        <div>
                            {this.state.students.map(s =>
                                <div class="list">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Project ID</th>
                                                <th>Course ID</th>
                                                <th>Course Name</th>
                                                <th>Semester</th>
                                                <th>Assignment name:</th>
                                                <th>Detail</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>

                                                <td>{s.id}</td>
                                                <td>{s.courseId}</td>
                                                <td>{s.courseName}</td>
                                                <td>{s.semester}</td>
                                                <td>{s.asgName}</td>

                                                <Link to={`/StudentDetail/${s.id}`}>
                                                    <a href="#" class="btn btn-primary mt-2 mr-2 ml-2">Detail</a>
                                                </Link>

                                            </tr>

                                        </tbody>
                                    </table>

                                    <button class="btn btn-dark mb-2 mr-2" onClick={this.delete.bind(this, s.id)}>Delete</button>

                                    <button class="btn btn-dark mb-2 mr-2" onClick={this.edit.bind(this, s.id, s.s1Id, s.s1Name, s.s1Year, s.s2Id, s.s2Name, s.s2Year, s.s3Id, s.s3Name, s.s3Year, s.courseId, s.courseName, s.semester, s.asgName, s.asgDescription, s.asgPercentage, s.techUsed, s.scope, s.description, s.industryLink, s.application, s.photo, s.photo2, s.photo3)}>Edit</button>
                                    <br />
                                </div>
                            )}
                            <br />
                        </div>

                    </div>
                </div>

            </div>
        )
    }

}
