import React from 'react';
const url1 = "http://localhost:9000/admins"
export default class AdminLogin extends React.Component {
    constructor() {
        super()

        this.state = {
            insertName: '',
            insertPassword: '',
            message: '',
            admins: [],
            id: '',
            name: '',
            password: ''

        }
    }

   
    fetchData() {
        fetch(url1).then(res => res.json())
            .then(json => {

                var list = json.filter(s => typeof s.id !== 'undefined' && s.id !== "" && s.name !== 'undefined' && s.name !== "")
                this.setState({ admins: list })
            })
    }

    componentDidMount() {
        this.fetchData()
    }

    handleChange(e) {
        this.setState({ [e.target.name]: e.target.value })
    }

    //check name and password 

    handleLogin(e) {
        e.preventDefault()
        fetch(url1).then(res => res.json())
        
     

        for (let i = 0; i < this.state.admins.length; i++) {
            if (this.state.insertName === this.state.admins[i].name) {
                if (this.state.insertPassword === this.state.admins[i].password) {
                 
                    this.props.history.push('/DifferentView');
            
                } else {
                    this.setState({message:"Invalid name or password! Please try again. "})
                    return false;
                }
            }

        }
        this.setState({message:"Invalid name or password! Please try again. "})
    }




    render() {


        return (

            <div class=" container mb-sm-5">
                <div class="row">
                    <div class="col-md-3"></div>
                    <div class="col-md-6">

                        <div class="card">
                            <br />
                          
                            {/* Admin login form */}
                            <h2 class=" pl-4">Log in as Admin:</h2>
                            <form onSubmit={this.handleLogin.bind(this)} class=" mb-4 pl-4  pt-2 pm-2">
                                <div className="form-group row">
                                    <div className="col-sm-10">
                                        Name:
                                        <input type="text" name="insertName" className="form-control" placeholder="Name" value={this.state.insertName} onChange={this.handleChange.bind(this)}
                                        />
                                    </div>
                                </div>
                                <div className="form-group row">
                                    <div className="col-sm-10">
                                        Password:
                                        <input type="text" name="insertPassword" className="form-control" placeholder="Password" value={this.state.insertPassword} onChange={this.handleChange.bind(this)}
                                        />
                                    </div>
                                </div>
                                <div className="form-group row">
                                    <div className="col-sm-10" >
                                        <button type="submit" className="btn btn-primary" class=" btn btn-success mb-2 ">Log in</button>
                                    </div>
                                    {/* Display error message if user entered wrong name or password */}
                                    <h5 style={{ color: "red" }}>{this.state.message}</h5>
                                </div>
                            </form>

                        </div>
                    </div>
                    <div class="col-md-3"></div>
                </div>

            </div>
        )
    }
}