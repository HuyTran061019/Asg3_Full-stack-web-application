import React from 'react'
import { BrowserRouter, Link, Route, Switch } from 'react-router-dom'
import Student from './Student.jsx'
import DifferentView from './DifferentView.jsx'


const url = 'http://localhost:9000/students'

export default class StudentDetail extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            Setid: this.props.match.params.id,
            students: [],
            id: '',

            s1Id: '',
            s1Name: '',
            s1Year: '',

            s2Id: '',
            s2Name: '',
            s2Year: '',

            s3Id: '',
            s3Name: '',
            s3Year: '',

            courseId: '',
            courseName: '',
            semester: '',
            asgName: '',
            asgDescription: '',
            asgPercentage: '',
            techUsed: '',
            scope: '',
            description: '',
            industryLink: '',
            application: '',
            photo: '',
            photo2: '',
            photo3: ''

        }

    }
    fetchData() {


        fetch(url + "/" + this.state.Setid)
            .then(res => res.json())
            .then(json => this.setState({ students: json }))
    }
    componentDidMount() {

        this.fetchData()
    }




    render() {
        return (

            <div class="container mb-3">
                <div>
                    {this.state.students.map(s =>
                        <div>
                            <h1 class="font-weight-bold" style={{ color: "red" }}> Project Detail: </h1>
                            <br />
                            {/* Course info */}
                            <h2 style={{ color: "midnightblue" }} class="font-weight-bold"> Course Info:   </h2>
                            <div class="card mb-2" >
                                <div class="card-body border border black" >

                                    <h4 class="font-weight-bold">Course name : {s.courseName}</h4>
                                    <h4>Course id :{s.courseId}</h4>
                                    <h5>Semester: {s.semester} </h5>

                                </div>
                            </div>
                            {/* Assignment info */}
                            <h2 style={{ color: "midnightblue" }} class="font-weight-bold"> Assignment Detail:</h2>
                            <div class="card mb-2" >
                                <div class="card-body border border black" >
                                    <h4 class="font-weight-bold">Assignment name : {s.asgName}</h4>
                                    <h6>Total percentage :{s.asgPercentage}</h6>
                                    <br />

                                    <h6 class="mb-2">Assignment detail: {s.asgDescription}</h6>
                                </div>
                            </div>
                            {/* List out student in Project */}
                            <h2 style={{ color: "midnightblue" }} class="font-weight-bold"> Student in project list:</h2>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Student ID</th>
                                        <th>Student Name</th>
                                        <th>Student Year</th>


                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>

                                        <td>{s.s1Id}</td>
                                        <td>{s.s1Name}</td>
                                        <td>{s.s1Year}</td>

                                    </tr>
                                    <tr>

                                        <td>{s.s2Id}</td>
                                        <td>{s.s2Name}</td>
                                        <td>{s.s2Year}</td>

                                    </tr>
                                    <tr>

                                        <td>{s.s3Id}</td>
                                        <td>{s.s3Name}</td>
                                        <td>{s.s3Year}</td>

                                    </tr>

                                </tbody>
                            </table>
                            {/* Scope and others */}
                            <h2 style={{ color: "midnightblue" }} class="font-weight-bold"> Scope Detail:</h2>
                            <div class="card mb-2" >
                                <div class="card-body border border black" >

                                    <h6>Scope :{s.scope}</h6>
                                    <br />

                                    <h6 class>Description : {s.description}</h6>

                                    <h6>Industry Link :{s.industryLink}</h6>

                                    <h6 class="mb-2"> Application : {s.application}</h6>

                                </div>
                            </div>
                            {/* Photos  */}
                            <h2 style={{ color: "midnightblue" }} class="font-weight-bold">Photos:</h2>
                      

                            <img src={'http://localhost:9000/uploads/' + s.photo}
                                style={{ width: "500px", height: "500px" }}
                                alt="Some photos" />


                            <img src={'http://localhost:9000/uploads/' + s.photo2}
                                style={{ width: "500px", height: "500px" }}
                                alt="Some photos" />

                            <img src={'http://localhost:9000/uploads/' + s.photo3}
                                style={{ width: "500px", height: "500px" }}
                                alt="Some photos" />



                        </div>


                    )}
                </div>
            </div>

        )
    }
}