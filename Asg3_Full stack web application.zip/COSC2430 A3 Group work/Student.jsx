import React from 'react'
import { BrowserRouter, Link, Route } from 'react-router-dom'


const url = 'http://localhost:9000/students'
const url2 = 'http://localhost:9000/categories'
const url3 = 'http://localhost:9000/semesters'

export default class DifferentView extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            // students project 
            students: [],
            id: '',

            s1Id: '',
            s1Name: '',
            s1Year: '',

            s2Id: '',
            s2Name: '',
            s2Year: '',

            s3Id: '',
            s3Name: '',
            s3Year: '',

            courseId: '',
            courseName: '',
            semester: '',
            asgName: '',
            asgDescription: '',
            asgPercentage: '',
            techUsed: '',
            scope: '',
            description: '',
            industryLink: '',
            application: '',
            photo: '',
            photo2: '',
            photo3: '',

            addNew: true,
            filtered: [],
            keywordSearch: '',

            // courses
            categories: [],
            categoriesId: '',
            categoriesName: '',
            // semesters
            sems: [],
            semsId: '',
            semsName: ''



        }

    }
    //No filter function
    fetchProduct() {
        fetch(url).then(res => res.json())
            .then(json => {

                var list = json.filter(s => typeof s.id !== 'undefined' && s.id !== "")
                this.setState({ students: list })
            })
    }
    //Filter with course function
    fetchCourse(name) {
        fetch(url).then(res => res.json())
            .then(json => {

                var list = json.filter(s => typeof s.id !== 'undefined' && s.id !== "" && s.courseName == name)
                this.setState({ students: list })
            })
    }
    //Filter with semester function
    fetchSemester(name) {
        fetch(url).then(res => res.json())
            .then(json => {

                var list = json.filter(s => typeof s.id !== 'undefined' && s.id !== "" && s.semester == name)
                this.setState({ students: list })
            })
    }




    fetchSearch(wordSearch) {
        fetch(url).then(res => res.json())
            .then(json => {

                var list = json.filter(s => typeof s.id !== 'undefined' && s.id !== "" && (s.courseName.toLowerCase()).includes(wordSearch.toLowerCase()))


                this.setState({ students: list })
            })


    }

    fetchData() {
        fetch(url).then(res => res.json())
            .then(json => {

                var list = json.filter(s => typeof s.id !== 'undefined' && s.id !== "")
                this.setState({ students: list })
            })
    }

    fetchData2() {
        fetch(url2).then(res => res.json())
            .then(json => {

                var list = json.filter(s => typeof s.id !== 'undefined' && s.id !== "" && s.name !== 'undefined' && s.name !== "")
                this.setState({ categories: list })
            })
    }

    fetchData3() {
        fetch(url3).then(res => res.json())
            .then(json => {

                var list = json.filter(s => typeof s.id !== 'undefined' && s.id !== "" && s.name !== 'undefined' && s.name !== "")
                this.setState({ sems: list })
            })
    }



    componentDidMount() {
        this.fetchData()
        this.fetchData2()
        this.fetchData3()

    }

    handleChange(e) {
        var obj = {}
        obj[e.target.name] = e.target.value
        this.setState(obj)
    }


    render() {
        return (
            <div class="container mt-n3">
                <div class="row">
                    <div class="col-md-4" style={{ backgroundColor: 'lightgrey' }} >


                        <div>

                            <br />
                          
                            {/* Search Bar */}
                            <h3>  Search for Project's course:</h3>
                          
                            <input type="text" placeholder="Course" id="keywordSearch" name="keywordSearch"
                            onChange={this.handleChange.bind(this)} value={this.state.keywordSearch} />
                            <button class="btn btn-success " onClick={this.fetchSearch.bind(this,this.state.keywordSearch)}>Search</button>
                             {/* Semester filter*/}
                            <h3> Filter option: </h3>

                            <div class="dropdown mt-3 mb-2">
                                <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" style={{ width: "100%" }}>Semesters
    <span class="caret"></span></button>
                                <ul class='dropdown-menu' style={{ width: "100%" }}>

                                    {/* show list of Semesters*/}

                                    {this.state.sems.map(i =>
                                        <div>
                                            <li  ><a href="#" onClick={this.fetchSemester.bind(this, i.name)}>{i.name}</a></li>
                                        </div>
                                    )}
                                    <li  ><a href="#" onClick={this.fetchProduct.bind(this)}>No Filter</a></li>
                                </ul>
                            </div>


                            {/* Coures Filter */}
                            <div class="dropdown mb-10">
                                <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" style={{ width: "100%" }}>Courses
    <span class="caret"></span></button>
                                <ul class='dropdown-menu' style={{ width: "100%" }}>

                                    {/* show list of Categories*/}

                                    {this.state.categories.map(i =>
                                        <div>
                                            <li  ><a href="#" onClick={this.fetchCourse.bind(this, i.name)}>{i.name}</a></li>
                                        </div>
                                    )}
                                    <li  ><a href="#" onClick={this.fetchProduct.bind(this)}>No Filter</a></li>
                                </ul>
                            </div>


                        </div>
                    </div>
                    <div class="col-md-8">


                        {/* show list of student projects +CRUD */}
                        <h2>Student project list: </h2>
                        <div>
                            {this.state.students.map(s =>
                                <div class="list">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Project ID</th>
                                                <th>Course ID</th>
                                                <th>Course Name</th>
                                                <th>Semester</th>
                                                <th>Assignment name:</th>
                                                <th>Detail</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>

                                                <td>{s.id}</td>
                                                <td>{s.courseId}</td>
                                                <td>{s.courseName}</td>
                                                <td>{s.semester}</td>
                                                <td>{s.asgName}</td>


                                                <Link to={`/StudentDetail/${s.id}`}>
                                                    <a href="#" class="btn btn-primary mt-2 mr-2 ml-2">Detail</a>
                                                </Link>

                                            </tr>

                                        </tbody>
                                    </table>

                                    <br />
                                </div>
                            )}
                            <br />
                        </div>

                    </div>
                </div>

            </div>
        )
    }

}
