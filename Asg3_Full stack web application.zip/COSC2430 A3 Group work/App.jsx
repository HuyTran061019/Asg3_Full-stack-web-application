import React from 'react'

import { BrowserRouter, Link, Route, Switch } from 'react-router-dom'

import StudentDetail from './StudentDetail.jsx'
import Student from './Student.jsx'
import DifferentView from './DifferentView.jsx'
import AdminLogin from './AdminLogin.jsx'
import AdminManagement from './AdminMangagement.jsx'



export default class App extends React.Component {
    render() {
        return (
            <div>
                <div class="jumbotron jumbotron-fluid" style={{ margin: 0, backgroundColor: 'MidnightBlue  ' }} >
                    <div class="container">

                        <div class="row">
                            <div class="col-md-2">
                                <img src="https://i0.wp.com/chame.rmit.edu.vn/wp-content/uploads/2017/09/Logo-02.png?fit=230%2C230&ssl=1" style={{ width: '130px', height: '120px' }} alt="" />
                            </div>

                            <div class="col-md-10">
                                <br />
                                <h1 style={{ color: 'white' }}>Student Project Artefacts</h1>
                                <p style={{ color: 'white' }}>Website for RMIT Student</p>
                            </div>
                        </div>



                    </div>
                </div>
                {/* Navigation bar with 2 button: User View and Admin Login */}
                <BrowserRouter>
                    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">

                        <ul className="navbar-nav align-items-center">
                            <li className="nav-item ml-5">
                                <Link to="/" className="nav-link">
                                    User View
                </Link>
                            </li>
                        </ul>
                        <ul className="navbar-nav align-items-center">
                            <li className="nav-item ml-5">
                                <Link to="/AdminLogin" className="nav-link">
                                    Admin login
                </Link>
                            </li>
                        </ul>

                    </nav>


                    <ul>

                    </ul>

                    {/* Go to another component */}
                    <Switch>
                   
                        <Route  exact path='/' component={Student} />
                        <Route path='/DifferentView' component={DifferentView} />
                        <Route path='/AdminLogin' component={AdminLogin} />
                        <Route path='/AdminManagement' component={AdminManagement} />
                        <Route path={'/StudentDetail/:id'} component={StudentDetail} />

                    </Switch>


                </BrowserRouter>
                <div class="jumbotron jumbotron-fluid" style={{ margin: 0, backgroundColor: 'ligthgrey ' }} >
                    <div class="container ">
                        <div class="row ">
                            <div class="col-md-3 pr-1" >
                                <h6 >Studying at RMIT</h6>
                                <div >Bachelor program</div>
                                <div> Post-graduate program</div>
                                <div> International student</div>
                                <div> Exchange to RMIT Melbourne</div>
                                <div> Scholarship</div>
                                <div> Frequently asked question</div>

                            </div>
                            <div class="col-md-3 pr-1" >
                                <h6 >About RMIT</h6>
                                <div >Life at RMIT</div>
                                <div> Clubs at school</div>
                                <div> Student support</div>
                                <div> Opportunies </div>

                            </div>
                            <div class="col-md-3 pr-1" >
                                <h6 >Payment method</h6>
                                <img src="https://i0.wp.com/www.sakuramobile.jp/wp-content/themes/FoundationPress/dist/assets/images/image-payment-method-card-360x240.png?resize=360%2C240&ssl=1" alt="Payment card method" width="200px" />

                            </div>
                            <div class="col-md-3 pr-1" >
                                <h6 >Connect with us</h6>
                                <img src="https://cdn130.picsart.com/257361938030212.png" alt="social media logo" width="200px" />


                            </div>

                        </div>
                    </div>
                </div>



            </div>

        )
    }
}
