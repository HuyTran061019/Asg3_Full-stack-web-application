const app = require('express')()
const express = require('express');
// const app = express();

const path = require('path')

var mongoose = require('mongoose')

var bodyParser = require('body-parser')


const multer = require('multer')

const axios = require('axios');


app.use(bodyParser.json())

var cors = require('cors')

app.use('/uploads',express.static(path.join(__dirname, 'uploads')))
app.use(cors())





//upload file
const myStrorage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads')
    },
    filename: function (req, file, cb) {
        cb(null, file.originalname)
    }
})

const uploader = multer({ storage: myStrorage })


app.post('/uploadfile', uploader.single('myFile'), function (req, res, next) {

    const file = req.file
    if (!file) {
      const error = new Error('Please upload a file')
      error.httpStatusCode = 400
      return next(error)
    }

    res.send(req.file)
})


//create a connection to database
mongoose.connect('mongodb://localhost/assignment3')




// define a "table" structure
var StudentSchema = new mongoose.Schema(
    {
        id: String,

        s1Id: String,
        s1Name: String,
        s1Year: String,

        s2Id: String,
        s2Name: String,
        s2Year: String,

        s3Id: String,
        s3Name: String,
        s3Year: String,

        courseId: String,
        courseName: String,
        semester: String,
        asgName: String,
        asgDescription: String,
        asgPercentage: String,
        techUsed: String,
        scope: String,
        description: String,
        industryLink: String,
        application: String,
        photo: String,
        photo2: String,
        photo3: String


    }
)
var AdminSchema = new mongoose.Schema(
    {
        id: String,
        name: String,
        password: String


    }
)

var CategorySchema = new mongoose.Schema(
    {
        id: String,
        name: String,


    }
)
var SemesterSchema = new mongoose.Schema(
    {
        id: String,
        name: String,


    }
)
mongoose.set('useFindAndModify', false);
//create a model             'Student':   this can be what ever i want
// ==> students (database collection)
var Student = mongoose.model('Student', StudentSchema)

var Admin = mongoose.model('Admin', AdminSchema)

var Category = mongoose.model('Category', CategorySchema)

var Semester = mongoose.model('Semester', SemesterSchema)

//Semester function
app.get('/semesters', function (req, res) {
    Semester.find({}, function (err, semesters) {
        res.send(semesters)
    })
})

app.post('/semesters', function (req, res) {
    Semester.create(req.body, function (err, semesters) {
        res.send(semesters)
    })
})

app.delete('/semesters/:id', function (req, res) {
    Semester.deleteOne({ id: req.params.id }, function (err, result) {
        res.send(result)
    })
})

app.put('/semesters/', function (req, res) {
    Semester.findOneAndUpdate({ id: req.body.id }, { name: req.body.name }, function (err, result) {
        res.send(result)
    })
})



//Category function
app.get('/categories', function (req, res) {
    Category.find({}, function (err, categories) {
        res.send(categories)
    })
})

app.post('/categories', function (req, res) {
    Category.create(req.body, function (err, categories) {
        res.send(categories)
    })
})

app.delete('/categories/:id', function (req, res) {
    Category.deleteOne({ id: req.params.id }, function (err, result) {
        res.send(result)
    })
})

app.put('/categories/', function (req, res) {
    Category.findOneAndUpdate({ id: req.body.id }, { name: req.body.name }, function (err, result) {
        res.send(result)
    })
})

//Admin functions
app.get('/admins', function (req, res) {
    Admin.find({}, function (err, admins) {
        res.send(admins)
    })
})

app.get('/admins/:id', function (req, res) {
    Admin.find({ id: req.params.id }, function (err, admins) {
        res.send(admins)
    })
})

app.post('/admins', function (req, res) {
    Admin.create(req.body, function (err, admins) {
        res.send(admins)
    })
})

app.delete('/admins/:id', function (req, res) {
    Admin.deleteOne({ id: req.params.id }, function (err, result) {
        res.send(result)
    })
})

app.put('/admins/', function (req, res) {
    Admin.findOneAndUpdate({ id: req.body.id }, { name: req.body.name, password: req.body.password }, function (err, result) {
        res.send(result)
    })
})

//Student functions
app.get('/students', function (req, res) {
    Student.find({}, function (err, students) {
        res.send(students)
    })
})

app.get('/students/:id', function (req, res) {
    Student.find({ id: req.params.id }, function (err, students) {
        res.send(students)
    })
})

app.post('/students', function (req, res) {
    Student.create(req.body, function (err, student) {
        res.send(student)
    })
})

app.delete('/students/:id', function (req, res) {
    Student.deleteOne({ id: req.params.id }, function (err, result) {
        res.send(result)
    })
})


app.put('/students/', function (req, res) {
    Student.findOneAndUpdate({ id: req.body.id }, {
        s1Id: req.body.s1Id, s1Name: req.body.s1Name, s1Year: req.body.s1Year, s2Id: req.body.s2Id, s2Name: req.body.s2Name, s2Year: req.body.s2Year, s3Id: req.body.s3Id, s3Name: req.body.s3Name, s3Year: req.body.s3Year, courseId: req.body.courseId, courseName: req.body.courseName, semester: req.body.semester, asgName: req.body.asgName, asgDescription: req.body.asgDescription, asgPercentage: req.body.asgPercentage, techUsed: req.body.techUsed, scope: req.body.scope,
        description: req.body.description, industryLink: req.body.industryLink, application: req.body.application, photo: req.body.photo, photo2: req.body.photo2, photo3: req.body.photo3
    }, function (err, result) {
        res.send(result)
    })
})


app.get('/students/search', function (req, res) {
    Student.find(
        { name: { $regex: req.query.name } },
        {
            skip: 0, // Starting Row
            limit: 10, // Ending Row
            sort: {
                name: -1 //Sort by Date Added DESC
            }
        },
        function (err, students) {
            if (err) handleError(err)
            res.send(students)
        })
})

function handleError(err) {
    console.log(err)
}




app.listen(9000)