import React from 'react';
import {
    withRouter
} from 'react-router-dom';
import { Link } from 'react-router-dom'
const url = "http://localhost:9000/admins"
export default class AdminManagement extends React.Component {
    constructor() {
        super()
        //admin
        this.state = {
            admins: [],
            id: '',
            name: '',
            password: '',
            addNew: true

        }
    }
    fetchData() {
        fetch(url).then(res => res.json())
            .then(json => {

                var list = json.filter(s => typeof s.id !== 'undefined' && s.id !== "" && s.name !== 'undefined' && s.name !== "")
                this.setState({ admins: list })
            })
    }

    componentDidMount() {
        this.fetchData()
    }

    handleChange(e) {
        this.setState({ [e.target.name]: e.target.value })
    }

    save() {
        if (this.state.addNew === true) {
            fetch(url, {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ id: this.state.id, name: this.state.name, password: this.state.password })
            }).then(res => res.json())
                .then(json => this.fetchData())
        }
        else {
            fetch(url, {
                method: 'put',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ id: this.state.id, name: this.state.name, password: this.state.password })
            }).then(res => res.json())
                .then(json => this.fetchData())
        }

    }


    delete(id) {
        if (confirm('Do you want to delete?')) {
            fetch(url + "/" + id, {
                method: 'delete',
            }).then(res => res.json())
                .then(json => this.fetchData())
        }

    }



    add(id, name, password) {
        this.setState({ id: '', name: '', password: '', addNew: true })
    }

    edit(id, name, password) {
        this.setState({ id: id, name: name, password: password, addNew: false })
    }

    render() {


        return (

            <div class=" container mt-n3">
                <div class="row">
                    <div class="col-md-4" style={{ backgroundColor: 'lightgrey' }}>
                        <br />

                        <Link to="/DifferentView" className="nav-link">
                            <button class="btn btn-primary" style={{ width: "100%", height: "50px" }}>
                                Back to Admin view
                                   </button>
                        </Link>

                    </div>
                    <div class="col-md-8">

                        <br />
                        {/* CRUD Admin */}
                        <h3>Admin Management:</h3>
                        <div class="card mb-4 pl-4 pr-4 pt-5 pm-5" >

                            <h3>Add/Change Admin :</h3>
                            Admin id: <input class="mt-1" type="text" id="id" name="id" className="form-control" value={this.state.id}
                                onChange={this.handleChange.bind(this)} />
                            <br />
                            Admin name: <input class="mt-1" type="text" id="name" name="name" className="form-control" value={this.state.name}
                                onChange={this.handleChange.bind(this)} />
                            <br />
                            Admin password: <input class="mt-1" type="text" id="password" name="password" className="form-control" value={this.state.password}
                                onChange={this.handleChange.bind(this)} />
                            <br />
                            <button class="btn btn-success  mr-1 mt-1" onClick={this.save.bind(this)}>Save</button>
                            <button class="btn btn-success  mr-1 mt-1" onClick={this.add.bind(this)}>Add new</button>
                            <br />

                        </div>
                        <h3>Admin list:</h3>
                        {/* List out admins */}
                        <div  >
                            {this.state.admins.map(i =>

                                <div class="list">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Admin Id</th>
                                                <th>Admin Name</th>
                                                <th>Admin Password</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>{i.id}</td>
                                                <td>{i.name}</td>
                                                <td>{i.password}</td>

                                            </tr>

                                        </tbody>
                                    </table>

                                    <br />
                                    <button class="btn btn-dark mb-2 mr-2" onClick={this.delete.bind(this, i.id)}>Delete</button>

                                    <button class="btn btn-dark mb-2 mr-2" onClick={this.edit.bind(this, i.id, i.name, i.password)}>Edit</button>
                                </div>

                            )}
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}