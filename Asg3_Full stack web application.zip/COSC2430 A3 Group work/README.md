# react-template

This puts up all the boiler plate used in a new React project. 
It contains a Hello component with a property (name)
Clone this when you want to work with React.
